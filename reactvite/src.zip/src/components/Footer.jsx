
function Footer() {
    return (
	<footer>
		 <span>©2025 Kevin Henriques</span>
	</footer>
    )
}

export default Footer;